/* Levi Mack */

#include "./hw4-levimack.h"


int comp(const void *x, const void *y){
	const char *p1 = *(const char**)x;
	const char *p2 = *(const char**)y;
	
	return strcasecmp(p1, p2);
}

int main(void) {

	int i, ind, j, total, t, f0c, f1c, f2c, big, added;
	char **arr;
	size_t pos;
		
	char file1[] = "american0.txt";
	char file2[] = "american1.txt";
	char file3[] = "american2.txt";
	char outfile[] = "words.txt";
	char c;

	//count the lines of each file
	f0c = foo(file1);
	f1c = foo(file2);
	f2c = foo(file3);
	
	big = biggest(file1) + 1;
	t = biggest(file2);
	if (t > big) {
		big = t + 1;	
	}	
	t = biggest(file3);
	if (t > big) {
		big = t + 1;
	}
	
	total = f0c + f1c + f2c; //total number of lines of data in the input files
	
	//open files to read data from
	FILE *fp0, *fp1, *fp2, *fout;

	fp0 = fopen(file1, "r");
	fp1 = fopen(file2, "r");
	fp2 = fopen(file3, "r");	

	//create dynamic array
	arr = (char **) calloc(total, sizeof(char *));
	for (i = 0; i < total; i++) {
		arr[i] = (char *) calloc(big, sizeof(char));
	}
	
	added = 0;
	ind = 0; //index of the array
	
	for (i = 0; i < f0c; i++) {
		for (pos = 0; pos < big;) {
			c = fgetc(fp0);
			if (c == EOF) {
				break;
			}
			if (!isalpha(c)) {
				if (c != '\'') {
					if (!pos) {
						continue;
					}
					else {
						break;
					}
				}
			}
			arr[ind][pos++] = c;			
		}
		arr[ind][pos] = '\0';
		added++;
		ind++;
	}
	
	for (i = 0; i < f1c; i++){	
		for (pos = 0; pos < big;) {
			c = fgetc(fp1);
			if (c == EOF) {
				break;
			}
			if (!isalpha(c)) {
				if (c != '\'') {
					if (!pos) {
						continue;
					}
					else {
						break;
					}
				}
			}
			arr[ind][pos++] = c;			
		}
		arr[ind][pos] = '\0';
		added++;
		ind++;
	}

	for (i = 0; i < f2c; i++){	
		for (pos = 0; pos < big;) {
			c = fgetc(fp2);
			if (c == EOF) {
				break;
			}
			if (!isalpha(c)) {
				if (c != '\'') {
					if (!pos) {
						continue;
					}
					else {
						break;
					}
				}
			}
			arr[ind][pos++] = c;			
		}
		arr[ind][pos] = '\0';
		added++;
		ind++;
	}

	fclose(fp0);	
	fclose(fp1);	
	fclose(fp2);

	qsort(arr,added,sizeof(char*),comp);
	
	bar(outfile, added,  arr);

	for (j = 1; j < total; j++) {
		free(arr[j]);
	}
	free(arr);	
	return 0;
}

int biggest(char *filename) {

	FILE *fin;
	int first, biggest, t;

	biggest = 0;
	t = 0;
	
	fin = fopen(filename, "r");
	first = fgetc(fin);
	
	if (first == '\n') {
		if (t > biggest) {
			biggest = t;
		}
		t = 0;
	}
	else {
		t++;
	}
	
	while (first != EOF) {
		first = fgetc(fin);
		if (first == '\n'){
			if (t > biggest) {
				biggest = t;
			}
			t = 0;
		}
		else {
			t++;
		}
	}
	fclose(fin);
	return biggest;
}

