/* Levi Mack */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//#ifndef _someNameA_
//#define _someNameA_

//int foo(char *filename);
//void bar(char *filename, int total, char **words);

//#endif
